# -*- coding: utf-8 -*-
"""
Пример приложения АИС: Система управления задачами
Демонстрация всех 5 этапов разработки ПО АИС
"""

import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime
import hashlib

class TaskManagementSystem:
    def __init__(self, root):
        self.root = root
        self.root.title("Система управления задачами - АИС")
        self.root.geometry("900x600")
        self.root.resizable(False, False)
        
        # Инициализация БД
        self.init_database()
        
        # Текущий пользователь
        self.current_user = None
        
        # Создание интерфейса
        self.create_login_screen()
    
    def init_database(self):
        """ЭТАП 3: Инициализация базы данных"""
        self.conn = sqlite3.connect('task_management.db')
        self.cursor = self.conn.cursor()
        
        # Таблица пользователей (ЭТАП 5: Безопасность - хранение паролей)
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Таблица задач
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS tasks (
                task_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                description TEXT,
                priority TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        # Таблица логов (ЭТАП 5: Аудит и мониторинг)
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS activity_log (
                log_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                action TEXT NOT NULL,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        self.conn.commit()
        
        # Создание демо-пользователя
        self.create_demo_user()
    
    def create_demo_user(self):
        """Создание демо-пользователя для тестирования"""
        try:
            password_hash = hashlib.sha256("demo123".encode()).hexdigest()
            self.cursor.execute(
                "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
                ("demo", password_hash, "user")
            )
            self.conn.commit()
        except sqlite3.IntegrityError:
            pass  # Пользователь уже существует
    
    def hash_password(self, password):
        """ЭТАП 5: Хэширование паролей для безопасности"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def log_activity(self, action):
        """ЭТАП 5: Логирование действий пользователей"""
        if self.current_user:
            self.cursor.execute(
                "INSERT INTO activity_log (user_id, action) VALUES (?, ?)",
                (self.current_user['user_id'], action)
            )
            self.conn.commit()
    
    def create_login_screen(self):
        """ЭТАП 4: Интерфейс - Экран входа"""
        # Очистка экрана
        for widget in self.root.winfo_children():
            widget.destroy()
        
        # Фрейм для центрирования
        login_frame = tk.Frame(self.root, bg='#2C3E50')
        login_frame.place(relx=0.5, rely=0.5, anchor='center')
        
        # Заголовок
        title_label = tk.Label(
            login_frame,
            text="🔐 Система управления задачами",
            font=("Arial", 20, "bold"),
            bg='#2C3E50',
            fg='white'
        )
        title_label.pack(pady=20)
        
        # Поле username
        tk.Label(login_frame, text="Логин:", bg='#2C3E50', fg='white', font=("Arial", 12)).pack(pady=5)
        self.username_entry = tk.Entry(login_frame, font=("Arial", 12), width=25)
        self.username_entry.pack(pady=5)
        self.username_entry.insert(0, "demo")
        
        # Поле password
        tk.Label(login_frame, text="Пароль:", bg='#2C3E50', fg='white', font=("Arial", 12)).pack(pady=5)
        self.password_entry = tk.Entry(login_frame, show="*", font=("Arial", 12), width=25)
        self.password_entry.pack(pady=5)
        self.password_entry.insert(0, "demo123")
        
        # Кнопка входа
        login_btn = tk.Button(
            login_frame,
            text="Войти",
            command=self.login,
            bg='#27AE60',
            fg='white',
            font=("Arial", 12, "bold"),
            width=20,
            cursor="hand2"
        )
        login_btn.pack(pady=20)
        
        # Информация
        info_label = tk.Label(
            login_frame,
            text="Демо: demo / demo123",
            font=("Arial", 9),
            bg='#2C3E50',
            fg='#BDC3C7'
        )
        info_label.pack()
    
    def login(self):
        """ЭТАП 5: Аутентификация пользователя"""
        username = self.username_entry.get()
        password = self.password_entry.get()
        
        if not username or not password:
            messagebox.showerror("Ошибка", "Заполните все поля!")
            return
        
        password_hash = self.hash_password(password)
        
        self.cursor.execute(
            "SELECT user_id, username, role FROM users WHERE username=? AND password_hash=?",
            (username, password_hash)
        )
        user = self.cursor.fetchone()
        
        if user:
            self.current_user = {
                'user_id': user[0],
                'username': user[1],
                'role': user[2]
            }
            self.log_activity(f"Вход в систему: {username}")
            self.create_main_screen()
        else:
            messagebox.showerror("Ошибка", "Неверный логин или пароль!")
    
    def create_main_screen(self):
        """ЭТАП 4: Главный экран приложения"""
        # Очистка экрана
        for widget in self.root.winfo_children():
            widget.destroy()
        
        # Верхняя панель
        top_frame = tk.Frame(self.root, bg='#34495E', height=60)
        top_frame.pack(fill='x')
        
        tk.Label(
            top_frame,
            text=f"👤 {self.current_user['username']} ({self.current_user['role']})",
            bg='#34495E',
            fg='white',
            font=("Arial", 12)
        ).pack(side='left', padx=20, pady=15)
        
        tk.Button(
            top_frame,
            text="Выход",
            command=self.logout,
            bg='#E74C3C',
            fg='white',
            font=("Arial", 10),
            cursor="hand2"
        ).pack(side='right', padx=20, pady=15)
        
        # Основной контейнер
        main_container = tk.Frame(self.root, bg='#ECF0F1')
        main_container.pack(fill='both', expand=True)
        
        # Левая панель - форма добавления задачи
        left_panel = tk.Frame(main_container, bg='white', width=300)
        left_panel.pack(side='left', fill='y', padx=10, pady=10)
        
        tk.Label(
            left_panel,
            text="➕ Новая задача",
            bg='white',
            font=("Arial", 14, "bold")
        ).pack(pady=10)
        
        # Название задачи
        tk.Label(left_panel, text="Название:", bg='white', font=("Arial", 10)).pack(anchor='w', padx=10)
        self.task_title_entry = tk.Entry(left_panel, font=("Arial", 11), width=28)
        self.task_title_entry.pack(padx=10, pady=5)
        
        # Описание
        tk.Label(left_panel, text="Описание:", bg='white', font=("Arial", 10)).pack(anchor='w', padx=10)
        self.task_desc_text = tk.Text(left_panel, font=("Arial", 10), width=28, height=5)
        self.task_desc_text.pack(padx=10, pady=5)
        
        # Приоритет
        tk.Label(left_panel, text="Приоритет:", bg='white', font=("Arial", 10)).pack(anchor='w', padx=10)
        self.priority_var = tk.StringVar(value="Средний")
        priority_combo = ttk.Combobox(
            left_panel,
            textvariable=self.priority_var,
            values=["Низкий", "Средний", "Высокий"],
            state='readonly',
            width=26,
            font=("Arial", 10)
        )
        priority_combo.pack(padx=10, pady=5)
        
        # Статус
        tk.Label(left_panel, text="Статус:", bg='white', font=("Arial", 10)).pack(anchor='w', padx=10)
        self.status_var = tk.StringVar(value="Новая")
        status_combo = ttk.Combobox(
            left_panel,
            textvariable=self.status_var,
            values=["Новая", "В работе", "Завершена"],
            state='readonly',
            width=26,
            font=("Arial", 10)
        )
        status_combo.pack(padx=10, pady=5)
        
        # Кнопка добавления
        tk.Button(
            left_panel,
            text="Добавить задачу",
            command=self.add_task,
            bg='#3498DB',
            fg='white',
            font=("Arial", 11, "bold"),
            cursor="hand2"
        ).pack(pady=15)
        
        # Правая панель - список задач
        right_panel = tk.Frame(main_container, bg='white')
        right_panel.pack(side='right', fill='both', expand=True, padx=10, pady=10)
        
        tk.Label(
            right_panel,
            text="📋 Список задач",
            bg='white',
            font=("Arial", 14, "bold")
        ).pack(pady=10)
        
        # Таблица задач
        columns = ('ID', 'Название', 'Приоритет', 'Статус', 'Дата создания')
        self.task_tree = ttk.Treeview(right_panel, columns=columns, show='headings', height=15)
        
        # Настройка колонок
        self.task_tree.heading('ID', text='ID')
        self.task_tree.heading('Название', text='Название')
        self.task_tree.heading('Приоритет', text='Приоритет')
        self.task_tree.heading('Статус', text='Статус')
        self.task_tree.heading('Дата создания', text='Дата создания')
        
        self.task_tree.column('ID', width=50)
        self.task_tree.column('Название', width=200)
        self.task_tree.column('Приоритет', width=100)
        self.task_tree.column('Статус', width=100)
        self.task_tree.column('Дата создания', width=150)
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(right_panel, orient='vertical', command=self.task_tree.yview)
        self.task_tree.configure(yscrollcommand=scrollbar.set)
        
        self.task_tree.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
        
        # Кнопки управления задачами
        button_frame = tk.Frame(right_panel, bg='white')
        button_frame.pack(pady=10)
        
        tk.Button(
            button_frame,
            text="Удалить задачу",
            command=self.delete_task,
            bg='#E74C3C',
            fg='white',
            font=("Arial", 10),
            cursor="hand2"
        ).pack(side='left', padx=5)
        
        tk.Button(
            button_frame,
            text="Обновить список",
            command=self.load_tasks,
            bg='#95A5A6',
            fg='white',
            font=("Arial", 10),
            cursor="hand2"
        ).pack(side='left', padx=5)
        
        # Загрузка задач
        self.load_tasks()
    
    def add_task(self):
        """Добавление новой задачи"""
        title = self.task_title_entry.get().strip()
        description = self.task_desc_text.get("1.0", "end-1c").strip()
        priority = self.priority_var.get()
        status = self.status_var.get()
        
        if not title:
            messagebox.showerror("Ошибка", "Введите название задачи!")
            return
        
        try:
            self.cursor.execute(
                """INSERT INTO tasks (user_id, title, description, priority, status, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (self.current_user['user_id'], title, description, priority, status, datetime.now())
            )
            self.conn.commit()
            self.log_activity(f"Создана задача: {title}")
            
            messagebox.showinfo("Успех", "Задача добавлена!")
            
            # Очистка полей
            self.task_title_entry.delete(0, 'end')
            self.task_desc_text.delete("1.0", "end")
            
            # Обновление списка
            self.load_tasks()
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось добавить задачу: {str(e)}")
    
    def load_tasks(self):
        """Загрузка задач из БД"""
        # Очистка таблицы
        for item in self.task_tree.get_children():
            self.task_tree.delete(item)
        
        # Загрузка задач текущего пользователя
        self.cursor.execute(
            """SELECT task_id, title, priority, status, created_at
               FROM tasks
               WHERE user_id=?
               ORDER BY created_at DESC""",
            (self.current_user['user_id'],)
        )
        
        tasks = self.cursor.fetchall()
        
        for task in tasks:
            # Форматирование даты
            date_str = task[4][:16] if task[4] else ""
            self.task_tree.insert('', 'end', values=(task[0], task[1], task[2], task[3], date_str))
    
    def delete_task(self):
        """Удаление выбранной задачи"""
        selected = self.task_tree.selection()
        
        if not selected:
            messagebox.showwarning("Предупреждение", "Выберите задачу для удаления!")
            return
        
        task_id = self.task_tree.item(selected[0])['values'][0]
        task_title = self.task_tree.item(selected[0])['values'][1]
        
        if messagebox.askyesno("Подтверждение", f"Удалить задачу '{task_title}'?"):
            self.cursor.execute("DELETE FROM tasks WHERE task_id=?", (task_id,))
            self.conn.commit()
            self.log_activity(f"Удалена задача: {task_title}")
            self.load_tasks()
            messagebox.showinfo("Успех", "Задача удалена!")
    
    def logout(self):
        """Выход из системы"""
        self.log_activity(f"Выход из системы: {self.current_user['username']}")
        self.current_user = None
        self.create_login_screen()
    
    def __del__(self):
        """Закрытие соединения с БД"""
        if hasattr(self, 'conn'):
            self.conn.close()

def main():
    root = tk.Tk()
    app = TaskManagementSystem(root)
    root.mainloop()

if __name__ == "__main__":
    main()
